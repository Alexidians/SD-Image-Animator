import pygame
import sys
import random
import time
import argparse
import threading
import math
import os
import moviepy.editor as mp  # For handling video and audio
import tkinter as tk
from tkinter import Tk, Button, Scale, Checkbutton, IntVar, HORIZONTAL
from tkinter import ttk
from PIL import Image

# Define explosion GIF paths array (replace with actual paths)
explosion_gifs = [
    "files/explosive_image/explode1.gif",
    "files/explosive_image/explode2.gif",
    "files/explosive_image/explode3.gif"
]

def load_gif_frames(gif_path):
    """
    Loads all frames of a GIF into a list of surfaces.
    
    Args:
        gif_path (str): Path to the GIF file.
        
    Returns:
        list: A list of pygame.Surface objects for each frame in the GIF.
    """
    gif = Image.open(gif_path)
    frames = []

    # Iterate through all frames in the GIF
    while True:
        frame = pygame.image.fromstring(gif.convert('RGBA').tobytes(), gif.size, 'RGBA')
        frames.append(frame)

        try:
            gif.seek(gif.tell() + 1)  # Move to the next frame
        except EOFError:
            break  # No more frames

    return frames

def explosion_thread(image_path, x_pos, y_pos, explosion_gif_path):
    """
    Handles the explosion animation in a separate thread.
    
    Args:
        image_path (str): Path to the background image.
        x_pos (int): The x position for the explosion.
        y_pos (int): The y position for the explosion.
        explosion_gif_path (str): Path to the explosion GIF.
    """
    # Load the explosion frames from the GIF
    explosion_frames = load_gif_frames(explosion_gif_path)
    num_frames = len(explosion_frames)
    frame_duration = 0.1  # Duration between frames

    # Initialize pygame and create a screen
    pygame.init()
    screen = pygame.display.get_surface()

    # Display each frame of the explosion GIF
    for frame in explosion_frames:
        # Redraw the background each time before displaying the explosion
        background_img = pygame.image.load(image_path)
        screen.blit(background_img, (0, 0))

        # Blit the explosion frame at the random position
        screen.blit(frame, (x_pos, y_pos))
        pygame.display.flip()  # Update the screen

        # Wait for the duration of one frame
        time.sleep(frame_duration)

    # After explosion completes, clear the explosion from the screen by redrawing the background
    background_img = pygame.image.load(image_path)
    screen.blit(background_img, (0, 0))
    pygame.display.flip()

def explosive_image(image_path):
    """
    Show explosions at random positions on the screen based on the background image size.
    Uses multiple explosion GIFs from an array. Trigger explosions at random intervals.
    
    Args:
        image_path (str): Path to the background image.
    """
    # Load background image to get the screen size dynamically
    background_img = Image.open(image_path)
    screen_width, screen_height = background_img.size  # Get the size of the background image

    # Initialize the screen
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("Explosive Video")

    # Infinite loop for continuous explosions
    running = True
    while running:
        # Handle Pygame events (allow closing the window)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Random interval between 1 and 3 seconds before the next explosion
        random_interval = random.uniform(1, 3)
        time.sleep(random_interval)

        # Random position for the explosion anywhere on the screen (avoid the ground)
        x_pos = random.randint(0, screen_width - 100)  # Random X position within bounds
        y_pos = random.randint(0, screen_height - 100)  # Random Y position within bounds

        # Randomly select an explosion GIF from the array
        explosion_gif_path = random.choice(explosion_gifs)

        # Start the explosion in a separate thread
        threading.Thread(target=explosion_thread, args=(image_path, x_pos, y_pos, explosion_gif_path)).start()

    # Close pygame after exiting the loop
    pygame.quit()



def load_break_stages(breaksize):
    # Load break stage images from destroy_stage_1.png to destroy_stage_9.png, resizing each to breaksize
    break_stages = []
    for i in range(1, 10):
        stage_path = f"files/mcbreak/destroy_stage_{i}.png"
        if os.path.exists(stage_path):
            stage_image = pygame.image.load(stage_path)
            stage_image = pygame.transform.scale(stage_image, (breaksize, breaksize))
            break_stages.append(stage_image)
        else:
            print(f"Warning: Missing {stage_path}")
            break_stages.append(None)
    return break_stages


def pixel_appearance(image_path, timer_per_pixel, pixels_per_timer, reverse=False):
    # Initialize pygame and load the image
    pygame.init()
    original_image = pygame.image.load(image_path)
    width, height = original_image.get_size()

    # Set up the display
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Pixel Appearance" if not reverse else "Pixel Disappearance")

    # Create the display image (start black for appearance, or full image for disappearance)
    display_image = pygame.Surface((width, height))
    if reverse:
        display_image.blit(original_image, (0, 0))
    else:
        display_image.fill((0, 0, 0))

    # Generate an array of all pixel positions
    pixel_positions = [f"{x}x{y}" for x in range(width) for y in range(height)]
    random.shuffle(pixel_positions)  # Shuffle positions for random appearance/disappearance

    # Main loop to render pixels in batches
    for i in range(0, len(pixel_positions), pixels_per_timer):
        # Handle events (like closing the window)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # Process a batch of pixels
        for pos in pixel_positions[i:i + pixels_per_timer]:
            x, y = map(int, pos.split("x"))
            if reverse:
                # In disappearance mode, turn pixel black
                display_image.set_at((x, y), (0, 0, 0))
            else:
                # In appearance mode, set pixel to original image color
                color = original_image.get_at((x, y))
                display_image.set_at((x, y), color)

        # Update the display
        screen.blit(display_image, (0, 0))
        pygame.display.flip()

        # Wait according to the timer
        time.sleep(timer_per_pixel)

    # Keep the window open until the user closes it
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

def ripple_distortion(image_path):
    """
    Creates a ripple effect that expands outwards from the center of the image.
    """
    if not os.path.exists(image_path):
        print("Image file not found!")
        return

    # Load the image
    image = pygame.image.load(image_path)
    image_rect = image.get_rect()

    # Set up display window
    screen = pygame.display.set_mode((image_rect.width, image_rect.height))
    pygame.display.set_caption("Ripple Distortion Effect")

    # Main loop for real-time ripple distortion
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Get the center of the image
        center_x, center_y = image_rect.width // 2, image_rect.height // 2
        time_offset = pygame.time.get_ticks() / 1000.0  # Controls ripple speed

        pixels = pygame.surfarray.pixels3d(image).copy()  # Copy to avoid modifying original

        # Apply ripple distortion effect
        for x in range(pixels.shape[0]):
            for y in range(pixels.shape[1]):
                # Calculate distance from the center
                distance = math.sqrt((x - center_x)**2 + (y - center_y)**2)
                # Offset based on a sine wave and distance from center for ripple effect
                ripple_offset = int(5 * math.sin(0.05 * distance - time_offset * 5))  # Adjust ripple size and frequency
                
                # Ensure y remains within bounds
                new_y = (y + ripple_offset) % pixels.shape[1]
                pixels[x, y] = pixels[x, new_y]

        # Update the modified image
        ripple_image = pygame.surfarray.make_surface(pixels)
        screen.blit(ripple_image, (0, 0))
        pygame.display.flip()



def color_shift(image_path):
    """
    Pulsates each pixel's brightness up and down over time, with each pixel independently increasing or decreasing.
    """

    pygame.init()
    
    # Load the image without using .convert()
    image = pygame.image.load(image_path)
    width, height = image.get_size()

    # Initialize the display
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Color Shift Effect")

    if not os.path.exists(image_path):
        print("Image file not found!")
        return

    # Initialize brightness directions for each pixel
    directions = [[random.choice([True, False]) for _ in range(height)] for _ in range(width)]

    # Main loop for real-time color shift
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Get the pixels of the image
        pixels = pygame.surfarray.pixels3d(image).copy()  # Copy to avoid modifying original

        # Modify brightness for each pixel based on direction
        for x in range(width):
            for y in range(height):
                r, g, b = pixels[x, y]
                
                # Increase brightness or decrease based on direction
                brightness_change = 10  # Increase brightness change for more noticeable effect
                if directions[x][y]:  # If direction is True, increase brightness
                    r, g, b = min(255, r + brightness_change), min(255, g + brightness_change), min(255, b + brightness_change)
                else:  # If direction is False, decrease brightness
                    r, g, b = max(0, r - brightness_change), max(0, g - brightness_change), max(0, b - brightness_change)
                
                # Update direction if the pixel has reached full brightness or darkness
                if r == 255 or g == 255 or b == 255:
                    directions[x][y] = False  # Start decreasing
                elif r == 0 or g == 0 or b == 0:
                    directions[x][y] = True   # Start increasing

                # Update the pixel color
                pixels[x, y] = (r, g, b)

        # Create a new surface with the modified pixels
        shifted_image = pygame.surfarray.make_surface(pixels)
        screen.blit(shifted_image, (0, 0))
        pygame.display.flip()

        # Optional: Add a delay for better visibility of the effect
        pygame.time.delay(20)  # 20ms delay (adjust as needed for smoother/faster effects)



def mcbreak(image_path, breaksize, automine):
    # Initialize pygame and load the image and break stages
    pygame.init()
    original_image = pygame.image.load(image_path)
    width, height = original_image.get_size()
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Minecraft Break Effect")

    # Load breaking stages and the final destroyed overlay
    break_stages = load_break_stages(breaksize)
    destroyed_image = pygame.image.load("files/mcbreak/destroyed.png")
    destroyed_image = pygame.transform.scale(destroyed_image, (breaksize, breaksize))

    # Track break stages per pixel and broken pixels for persistent display
    pixel_break_stages = {}
    broken_pixels = []

    def apply_break_stage(pixel, stage):
        """Apply the break stage overlay on the pixel position."""
        if stage < 9:
            overlay_image = break_stages[stage - 1]
            if overlay_image:  # Ensure the stage image exists
                overlay_x = pixel[0] - breaksize // 2
                overlay_y = pixel[1] - breaksize // 2
                screen.blit(overlay_image, (overlay_x, overlay_y))
        else:
            # Draw final destroyed overlay for pixels at stage 9
            overlay_x = pixel[0] - breaksize // 2
            overlay_y = pixel[1] - breaksize // 2
            screen.blit(destroyed_image, (overlay_x, overlay_y))
            if pixel not in broken_pixels:
                broken_pixels.append(pixel)

    def automine_pixel(pixel):
        """Handle the automatic mining process in another thread."""
        for stage in range(1, 10):
            pixel_break_stages[pixel] = stage
            apply_break_stage(pixel, stage)
            pygame.display.flip()
            time.sleep(0.5)  # 0.5 seconds between stages
        # Once finished, mark the pixel as completely destroyed
        pixel_break_stages[pixel] = 9
        apply_break_stage(pixel, 9)
        pygame.display.flip()

    while True:
        # Display the original image
        screen.blit(original_image, (0, 0))

        # Apply all persistent broken pixels overlays
        for pixel, stage in pixel_break_stages.items():
            apply_break_stage(pixel, stage)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = pygame.mouse.get_pos()
                pixel = (x, y)

                if automine:
                    # Start automine process for the clicked pixel in another thread
                    if pixel not in pixel_break_stages:
                        pixel_break_stages[pixel] = 0
                    threading.Thread(target=automine_pixel, args=(pixel,)).start()
                else:
                    # Manual break stage increment for each click
                    if pixel not in pixel_break_stages:
                        pixel_break_stages[pixel] = 0

                    # Increment the stage
                    pixel_break_stages[pixel] += 1
                    if pixel_break_stages[pixel] >= 9:
                        pixel_break_stages[pixel] = 9  # Set to final stage if maxed
                    apply_break_stage(pixel, pixel_break_stages[pixel])

                pygame.display.flip()

# Function to invert a pygame image (Surface object)
def invert_pygame_image(image_surface):
    # Get the dimensions of the image
    width, height = image_surface.get_size()

    # Loop through each pixel and invert the color
    for x in range(width):
        for y in range(height):
            # Get the current pixel color (RGBA)
            color = image_surface.get_at((x, y))

            # Invert the color (255 - each RGB channel)
            inverted_color = (255 - color[0], 255 - color[1], 255 - color[2], color[3])

            # Set the inverted color back to the pixel
            image_surface.set_at((x, y), inverted_color)

    return image_surface

def pixel_inversion(image_path, timer_per_pixel, pixels_per_timer, reverse=False):
    # Initialize pygame and load the image
    pygame.init()
    original_image = pygame.image.load(image_path)
    width, height = original_image.get_size()

    # Set up the display
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Pixel Inversion" if not reverse else "Pixel Uninversion")

    # Create the display image
    display_image = pygame.Surface((width, height))

    if reverse:
        # Start from the inverted image (all pixels are inverted from the original)
        for x in range(width):
            for y in range(height):
                color = original_image.get_at((x, y))
                inverted_color = (255 - color[0], 255 - color[1], 255 - color[2])
                display_image.set_at((x, y), inverted_color)
    else:
        # Start from the full original image
        display_image.blit(original_image, (0, 0))

    # Generate an array of all pixel positions
    pixel_positions = [f"{x}x{y}" for x in range(width) for y in range(height)]
    random.shuffle(pixel_positions)  # Shuffle positions for random inversion/uninversion

    # Function to invert a color
    def invert_color(color):
        return (255 - color[0], 255 - color[1], 255 - color[2])

    # Main loop to invert/uninvert pixels in batches
    for i in range(0, len(pixel_positions), pixels_per_timer):
        # Handle events (like closing the window)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # Process a batch of pixels
        for pos in pixel_positions[i:i + pixels_per_timer]:
            x, y = map(int, pos.split("x"))
            current_color = display_image.get_at((x, y))

            if reverse:
                # Gradually revert the pixel back to the original color (uninvert it)
                inverted_color = invert_color(current_color)
                display_image.set_at((x, y), inverted_color)
            else:
                # Gradually invert the pixel's color
                original_color = original_image.get_at((x, y))
                inverted_color = invert_color(original_color)
                display_image.set_at((x, y), inverted_color)

        # Update the display
        screen.blit(display_image, (0, 0))
        pygame.display.flip()

        # Wait according to the timer
        time.sleep(timer_per_pixel)

    # Keep the window open until the user closes it
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

def imgnuke(image_path):
    # Initialize pygame and load the image
    pygame.init()
    original_image = pygame.image.load(image_path)
    width, height = original_image.get_size()
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Image Nuker Effect")

    # Load nuke images
    nukemark_image = pygame.image.load("files/imgnuke/nukemark.png")
    explosion_image = pygame.image.load("files/imgnuke/explosion.png")
    explosionwasteland_image = pygame.image.load("files/imgnuke/explosionwasteland.png")
    
    # Resize images if necessary to fit the screen
    nukemark_image = pygame.transform.scale(nukemark_image, (width, height))
    explosion_image = pygame.transform.scale(explosion_image, (width, height))
    explosionwasteland_image = pygame.transform.scale(explosionwasteland_image, (width, height))

    def show_nuke_effect():
        """Display the nuke effect with the steps provided."""
        # Display nukemark
        screen.blit(nukemark_image, (0, 0))
        pygame.display.flip()
        time.sleep(3)  # Wait 3 seconds

        # Display explosion for 1 second
        screen.blit(explosion_image, (0, 0))
        pygame.display.flip()
        time.sleep(1)  # Wait 1 second

        # Display explosionwasteland permanently
        screen.blit(explosionwasteland_image, (0, 0))
        pygame.display.flip()

    while True:
        # Display the original image first
        screen.blit(original_image, (0, 0))

        # Check for events and quit the program if necessary
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            # Trigger the nuke effect when the mouse is clicked
            if event.type == pygame.MOUSEBUTTONDOWN:
                show_nuke_effect()

        pygame.display.flip()


if __name__ == "__main__":
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Pixel appearance/disappearance and mcbreak effect with pygame.")
    parser.add_argument("--action", required=True, choices=["pixelappearance", "pixeldisappearance", "mcbreak", "colorshift", "ripple_distortion", "pixelinversion", "pixeluninversion", "explosiveimage"], help="Action to perform.")
    parser.add_argument("--image", required=True, help="Path to the image.")
    parser.add_argument("--video", type=str, default="Please Provide A Video If Required!@#$%^&*()")
    parser.add_argument("--timerperpixel", type=float, default=0.05, help="Time per pixel.")
    parser.add_argument("--pixelspertimer", type=int, default=10, help="Number of pixels per timer interval.")
    parser.add_argument("--breaksize", type=int, default=16, help="Size of the break/crack overlay in pixels for mcbreak")
    parser.add_argument("--automine", action="store_true", help="Automatically cycle through break stages on single click.")
    args = parser.parse_args()

    # Execute the selected action
    if args.action == "pixelappearance":
        pixel_appearance(args.image, args.timerperpixel, args.pixelspertimer, reverse=False)
    elif args.action == "pixeldisappearance":
        pixel_appearance(args.image, args.timerperpixel, args.pixelspertimer, reverse=True)
    elif args.action == "mcbreak":
        mcbreak(args.image, args.breaksize, args.automine)
    elif args.action == "colorshift":
        color_shift(args.image)
    elif args.action == "ripple_distortion":
        ripple_distortion(args.image)
    if args.action == "pixelinversion":
        pixel_inversion(args.image, args.timerperpixel, args.pixelspertimer, reverse=False)
    elif args.action == "pixeluninversion":
        pixel_inversion(args.image, args.timerperpixel, args.pixelspertimer, reverse=True)
    elif args.action == "explosiveimage":
        explosive_image(args.image)